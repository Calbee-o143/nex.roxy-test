(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const config = window.DRIFT_CONFIG || {};
  const homeView = $("homeView");
  const browserView = $("browserView");
  const addressInput = $("addressInput");
  const toolbarInput = $("toolbarInput");
  const pageFrame = $("pageFrame");
  const emptyState = $("emptyState");
  const pageStatus = $("pageStatus");
  const tabsBar = $("tabsBar");
  let tabs = [{url:"", title:"New tab", history:[], index:-1}];
  let active = 0;

  function normalizeUrl(value) {
    let raw = value.trim();
    if (!raw) throw new Error("Enter a URL first.");
    if (!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(raw)) raw = "https://" + raw;
    let parsed;
    try { parsed = new URL(raw); } catch { throw new Error("That URL doesn't look valid."); }
    if (!["http:", "https:"].includes(parsed.protocol)) {
      throw new Error("Only HTTP and HTTPS URLs are supported.");
    }
    if (!parsed.hostname || parsed.username || parsed.password) {
      throw new Error("Enter a valid URL without embedded credentials.");
    }
    return parsed.href;
  }

  function setStatus(message, good=false) {
    pageStatus.innerHTML = "";
    const dot = document.createElement("span");
    dot.className = "status-dot";
    dot.style.background = good ? "#aaa" : "#777";
    const label = document.createElement("span");
    label.textContent = message;
    pageStatus.append(dot, label);
  }

  function renderTabs() {
    tabsBar.querySelectorAll(".tab").forEach(el => el.remove());
    const newTab = $("newTabButton");
    tabs.forEach((tab, i) => {
      const button = document.createElement("button");
      button.className = "tab" + (i === active ? " active" : "");
      button.innerHTML = '<span class="tab-dot"></span><span class="tab-name"></span><span class="tab-close">×</span>';
      button.querySelector(".tab-name").textContent = tab.title || "New tab";
      button.setAttribute("aria-label", tab.title || "New tab");
      button.addEventListener("click", e => {
        if (e.target.classList.contains("tab-close") && tabs.length > 1) {
          tabs.splice(i, 1);
          active = Math.max(0, Math.min(active - (i < active ? 1 : 0), tabs.length - 1));
          renderTabs(); showTab();
        } else {
          active = i; renderTabs(); showTab();
        }
      });
      tabsBar.insertBefore(button, newTab);
    });
  }

  function showTab() {
    const tab = tabs[active];
    toolbarInput.value = tab.url || "";
    if (!tab.url) {
      pageFrame.removeAttribute("src");
      emptyState.classList.remove("hidden");
      setStatus("Ready");
    } else {
      navigate(tab.url, false);
    }
  }

  function openBrowser() {
    homeView.classList.add("hidden");
    browserView.classList.remove("hidden");
  }

  function goHome() {
    browserView.classList.add("hidden");
    homeView.classList.remove("hidden");
    addressInput.focus();
  }

  async function navigate(value, addHistory=true) {
    let url;
    try { url = normalizeUrl(value); }
    catch (err) { setStatus(err.message); return; }

    const tab = tabs[active];
    if (addHistory) {
      tab.history = tab.history.slice(0, tab.index + 1);
      tab.history.push(url);
      tab.index = tab.history.length - 1;
    }
    tab.url = url;
    tab.title = new URL(url).hostname;
    toolbarInput.value = url;
    renderTabs();
    emptyState.classList.add("hidden");
    openBrowser();

    if (!config.proxyEndpoint) {
      pageFrame.removeAttribute("src");
      emptyState.classList.remove("hidden");
      setStatus("Backend not configured");
      emptyState.querySelector("h2").textContent = "Connect your backend first.";
      emptyState.querySelector("p").textContent =
        "Deploy the included Worker, add this domain to its allowlist, and set proxyEndpoint in config.js.";
      return;
    }

    setStatus("Requesting allowed destination…");
    try {
      const endpoint = new URL(config.proxyEndpoint);
      endpoint.searchParams.set("url", url);
      pageFrame.src = endpoint.href;
      setStatus("Opened viewer request", true);
    } catch {
      setStatus("Invalid backend URL");
    }
  }

  $("addressForm").addEventListener("submit", e => {
    e.preventDefault();
    navigate(addressInput.value);
  });
  $("toolbarForm").addEventListener("submit", e => {
    e.preventDefault();
    navigate(toolbarInput.value);
  });
  document.querySelectorAll("[data-url]").forEach(button =>
    button.addEventListener("click", () => navigate(button.dataset.url))
  );
  $("homeButton").addEventListener("click", goHome);
  $("backButton").addEventListener("click", () => {
    const tab = tabs[active];
    if (tab.index > 0) { tab.index--; tab.url = tab.history[tab.index]; showTab(); }
    else setStatus("No previous page in this tab");
  });
  $("forwardButton").addEventListener("click", () => {
    const tab = tabs[active];
    if (tab.index < tab.history.length - 1) { tab.index++; tab.url = tab.history[tab.index]; showTab(); }
    else setStatus("No next page in this tab");
  });
  $("reloadButton").addEventListener("click", () => {
    const tab = tabs[active];
    if (tab.url) navigate(tab.url, false);
  });
  $("newTabButton").addEventListener("click", () => {
    tabs.push({url:"", title:"New tab", history:[], index:-1});
    active = tabs.length - 1;
    renderTabs(); showTab(); openBrowser();
  });
  $("homeLink").addEventListener("click", e => { e.preventDefault(); goHome(); });
  $("helpButton").addEventListener("click", () => $("helpDialog").showModal());
  $("closeHelp").addEventListener("click", () => $("helpDialog").close());
  $("helpDialog").addEventListener("click", e => {
    if (e.target === $("helpDialog")) $("helpDialog").close();
  });

  renderTabs();
})();