/*
  Cloudflare Worker backend starter.
  This is intentionally allowlist-based, not an unrestricted open proxy.

  Before deploying:
  1. Replace ALLOWED_HOSTS with domains you own or are authorized to access.
  2. Deploy this Worker.
  3. Configure CORS_ORIGINS with your exact GitHub Pages origin.
  4. Set proxyEndpoint in ../config.js to https://YOUR-WORKER.workers.dev/proxy
*/
const ALLOWED_HOSTS = new Set([
  "example.com",
  "www.wikipedia.org",
  "wikipedia.org",
  "httpbin.org"
]);

const CORS_ORIGINS = new Set([
  "https://YOUR-GITHUB-USERNAME.github.io"
]);

function corsHeaders(origin) {
  const headers = {
    "Vary": "Origin",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (origin && CORS_ORIGINS.has(origin)) {
    headers["Access-Control-Allow-Origin"] = origin;
  }
  return headers;
}

function response(body, status, origin, extra = {}) {
  return new Response(body, {
    status,
    headers: {
      ...corsHeaders(origin),
      "Content-Type": "text/plain; charset=utf-8",
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "no-store",
      ...extra
    }
  });
}

function hostAllowed(hostname) {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  return [...ALLOWED_HOSTS].some(
    allowed => host === allowed || host.endsWith("." + allowed)
  );
}

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const origin = request.headers.get("Origin");

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: corsHeaders(origin)
      });
    }

    if (url.pathname === "/") {
      return new Response(
        "Drift proxy backend is running. Use /proxy?url=https%3A%2F%2Fexample.com",
        { headers: { "Content-Type": "text/plain; charset=utf-8" } }
      );
    }

    if (url.pathname !== "/proxy") {
      return response("Not found", 404, origin);
    }

    if (request.method !== "GET") {
      return response("Only GET requests are supported.", 405, origin);
    }

    if (!origin || !CORS_ORIGINS.has(origin)) {
      return response("This frontend origin is not allowed. Configure CORS_ORIGINS in worker.js.", 403, origin);
    }

    const targetValue = url.searchParams.get("url");
    if (!targetValue || targetValue.length > 2048) {
      return response("Supply a valid url query parameter.", 400, origin);
    }

    let target;
    try {
      target = new URL(targetValue);
    } catch {
      return response("Invalid destination URL.", 400, origin);
    }

    if (!["https:", "http:"].includes(target.protocol) ||
        target.username || target.password) {
      return response("Only HTTP and HTTPS destinations are supported.", 400, origin);
    }

    if (!hostAllowed(target.hostname)) {
      return response("Destination is not on the configured allowlist.", 403, origin);
    }

    try {
      const upstream = await fetch(target.href, {
        method: "GET",
        redirect: "manual",
        headers: {
          "Accept": request.headers.get("Accept") || "text/html,application/xhtml+xml,*/*",
          "User-Agent": "DriftViewer/1.0"
        },
        signal: AbortSignal.timeout(10000)
      });

      // Do not forward redirects automatically: each redirect must be checked
      // against the allowlist before it can be followed.
      if (upstream.status >= 300 && upstream.status < 400) {
        const location = upstream.headers.get("Location");
        if (!location) return response("Destination redirected without a location.", 502, origin);
        const redirected = new URL(location, target);
        if (!hostAllowed(redirected.hostname) ||
            !["http:", "https:"].includes(redirected.protocol)) {
          return response("Redirect destination is not on the configured allowlist.", 403, origin);
        }
        return response(
          "The destination redirected. Open this allowed URL directly: " + redirected.href,
          200,
          origin
        );
      }

      const contentType = upstream.headers.get("Content-Type") || "application/octet-stream";
      const safeTypes = [
        "text/html", "text/plain", "text/css", "application/json",
        "application/javascript", "text/javascript", "image/png",
        "image/jpeg", "image/gif", "image/webp", "image/svg+xml"
      ];
      const type = contentType.split(";")[0].trim().toLowerCase();

      if (!safeTypes.includes(type)) {
        return response("This content type is not served by the starter proxy: " + type, 415, origin);
      }

      const headers = new Headers(corsHeaders(origin));
      headers.set("Content-Type", contentType);
      headers.set("X-Content-Type-Options", "nosniff");
      headers.set("Cache-Control", "no-store");
      headers.set("Content-Security-Policy", "default-src 'self' data: blob: https: http:; frame-ancestors *; upgrade-insecure-requests");
      headers.set("Referrer-Policy", "no-referrer");

      return new Response(upstream.body, {
        status: upstream.status,
        headers
      });
    } catch (error) {
      return response("Upstream request failed or timed out.", 502, origin);
    }
  }
};
