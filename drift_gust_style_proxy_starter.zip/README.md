# Drift — Gust-style proxy starter

A dark, minimal browser-style frontend for GitHub Pages, plus a separate Cloudflare Worker backend.

## Important limitations

- GitHub Pages only serves static files. It cannot run the backend by itself.
- This starter uses an explicit domain allowlist. It is not an unrestricted public proxy.
- Many websites will not render fully through a basic fetch-based viewer. Login flows, complex JavaScript apps, cookies, relative assets, and sites that block embedding may not work.
- Use only on destinations and networks you are authorized to access. This project is not designed to bypass school, workplace, or other access controls.

## 1. Publish the frontend on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, `app.js`, and `config.js` from this folder to the repository root.
3. In the repository, open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish your site.

## 2. Configure the backend

1. Create a Cloudflare account and open Workers & Pages.
2. Create a Worker.
3. Paste the contents of `worker/worker.js` into the Worker editor and deploy it.
4. In `worker.js`, edit `ALLOWED_HOSTS` to include only destinations you own or are authorized to access.
5. Edit `CORS_ORIGINS` to contain the exact origin of your published GitHub Pages site. For example: `https://your-username.github.io`. If the repository is a project site, the origin is still the `https://your-username.github.io` part, not the repository path.
6. Deploy the Worker again and copy its `workers.dev` URL.

## 3. Connect the frontend

Edit `config.js` and set `proxyEndpoint` to the Worker URL plus `/proxy`, for example:

```js
window.DRIFT_CONFIG = {
  proxyEndpoint: "https://your-worker.your-subdomain.workers.dev/proxy"
};
```

Commit the change and wait for GitHub Pages to update.

## 4. Test

Start with `https://example.com`, which is included in the default allowlist. If you add a domain, add it to `ALLOWED_HOSTS` in the Worker and redeploy.

The starter intentionally returns clear errors when a destination is not allowed. It does not support arbitrary protocols, embedded credentials, or automatic redirects to unapproved hosts.

## Files

- `index.html` — page structure
- `style.css` — responsive dark UI
- `app.js` — URL bar, tabs, and navigation controls
- `config.js` — Worker endpoint setting
- `worker/worker.js` — allowlist-restricted backend
- `worker/wrangler.toml` — optional Wrangler deployment config
