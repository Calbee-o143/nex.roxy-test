/*
  Set this to your deployed Cloudflare Worker URL, for example:
  window.DRIFT_CONFIG = { proxyEndpoint: "https://your-worker.your-subdomain.workers.dev/proxy" };

  Leave empty until you have deployed and configured the backend.
*/
window.DRIFT_CONFIG = {
  proxyEndpoint: ""
};
